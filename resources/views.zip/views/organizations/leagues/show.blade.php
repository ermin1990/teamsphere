<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center justify-between">
            <div>
                <h2 class="font-bold text-3xl bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
                    {{ $league->name }}
                </h2>
                <p class="text-gray-400 mt-1">{{ $organization->name }}</p>
            </div>
            <div class="flex items-center space-x-4">
                <span class="px-3 py-1 text-sm rounded-full
                    @if($league->status === 'active') bg-green-500/20 text-green-400
                    @elseif($league->status === 'draft') bg-yellow-500/20 text-yellow-400
                    @elseif($league->status === 'completed') bg-blue-500/20 text-blue-400
                    @else bg-red-500/20 text-red-400 @endif"
                >
                    {{ ucfirst($league->status) }}
                </span>
            </div>
        </div>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">

                <div class="lg:col-span-2 space-y-6">

                    <div class="bg-gray-800/50 backdrop-blur-xl rounded-2xl p-6 border border-gray-700/50 shadow-xl">
                        <h3 class="text-xl font-semibold text-white mb-4">Detalji Lige</h3>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-sm font-medium text-gray-400 mb-1">Sport</label>
                                <p class="text-white">{{ $league->sport->name }}</p>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-400 mb-1">Tip Takmičenja</label>
                                <p class="text-white">{{ $league->is_team_based ? 'Timski' : 'Individualni' }}</p>
                            </div>
                            @if($league->start_date)
                            <div>
                                <label class="block text-sm font-medium text-gray-400 mb-1">Datum Početka</label>
                                <p class="text-white">{{ $league->start_date->format('M d, Y') }}</p>
                            </div>
                            @endif
                            @if($league->end_date)
                            <div>
                                <label class="block text-sm font-medium text-gray-400 mb-1">Datum Završetka</label>
                                <p class="text-white">{{ $league->end_date->format('M d, Y') }}</p>
                            </div>
                            @endif
                            @if($league->is_team_based && $league->max_teams)
                            <div>
                                <label class="block text-sm font-medium text-gray-400 mb-1">Maksimalno Timova</label>
                                <p class="text-white">{{ $league->max_teams }}</p>
                            </div>
                            @endif
                            <div>
                                <label class="block text-sm font-medium text-gray-400 mb-1">Kreirano</label>
                                <p class="text-white">{{ $league->created_at->format('M d, Y') }}</p>
                            </div>
                        </div>
                        @if($league->description)
                        <div class="mt-6">
                            <label class="block text-sm font-medium text-gray-400 mb-2">Opis</label>
                            <p class="text-white">{{ $league->description }}</p>
                        </div>
                        @endif
                    </div>

                    @if($league->status === 'active')
                    <div class="bg-gray-800/50 backdrop-blur-xl rounded-2xl p-6 border border-gray-700/50 shadow-xl">
                        <h3 class="text-xl font-semibold text-white mb-4">Tabela</h3>
                        <div class="overflow-x-auto">
                            <table class="w-full text-sm">
                                <thead>
                                    <tr class="border-b border-gray-700">
                                        <th class="text-left py-3 px-2 text-gray-400 font-medium">#</th>
                                        <th class="text-left py-3 px-2 text-gray-400 font-medium">{{ $league->is_team_based ? 'Tim' : 'Igrač' }}</th>
                                        <th class="text-center py-3 px-2 text-gray-400 font-medium">U</th>
                                        <th class="text-center py-3 px-2 text-gray-400 font-medium">P</th>
                                        <th class="text-center py-3 px-2 text-gray-400 font-medium">N</th>
                                        <th class="text-center py-3 px-2 text-gray-400 font-medium">I</th>
                                        <th class="text-center py-3 px-2 text-gray-400 font-medium">GD</th>
                                        <th class="text-center py-3 px-2 text-gray-400 font-medium">GR</th>
                                        <th class="text-center py-3 px-2 text-gray-400 font-medium">GR±</th>
                                        <th class="text-center py-3 px-2 text-gray-400 font-medium">Bod</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($league->standings->sortBy('position') as $standing)
                                    <tr class="border-b border-gray-700/50 hover:bg-gray-700/20">
                                        <td class="py-3 px-2 text-white font-medium">{{ $standing->position }}</td>
                                        <td class="py-3 px-2 text-white">{{ $standing->participant_name }}</td>
                                        <td class="py-3 px-2 text-center text-gray-300">{{ $standing->played }}</td>
                                        <td class="py-3 px-2 text-center text-green-400">{{ $standing->won }}</td>
                                        <td class="py-3 px-2 text-center text-yellow-400">{{ $standing->drawn }}</td>
                                        <td class="py-3 px-2 text-center text-red-400">{{ $standing->lost }}</td>
                                        <td class="py-3 px-2 text-center text-gray-300">{{ $standing->goals_for }}</td>
                                        <td class="py-3 px-2 text-center text-gray-300">{{ $standing->goals_against }}</td>
                                        <td class="py-3 px-2 text-center {{ $standing->goal_difference >= 0 ? 'text-green-400' : 'text-red-400' }}">
                                            {{ $standing->goal_difference >= 0 ? '+' : '' }}{{ $standing->goal_difference }}
                                        </td>
                                        <td class="py-3 px-2 text-center text-white font-bold">{{ $standing->points }}</td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>

                        @if(true)
                        <div class="mt-6 pt-6 border-t border-gray-600/50">
                            <h4 class="text-lg font-semibold text-white mb-4">{{ __('Pravila bodovanja') }}</h4>
                            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <div class="text-center">
                                    <div class="text-2xl font-bold text-green-400">{{ $league->settings['points_win'] ?? 3 }}</div>
                                    <div class="text-sm text-gray-400">{{ __('Bodovi za pobjedu') }}</div>
                                </div>
                                <div class="text-center">
                                    <div class="text-2xl font-bold text-yellow-400">{{ $league->settings['points_draw'] ?? 1 }}</div>
                                    <div class="text-sm text-gray-400">{{ __('Bodovi za neriješeno') }}</div>
                                </div>
                                <div class="text-center">
                                    <div class="text-2xl font-bold text-red-400">{{ $league->settings['points_loss'] ?? 0 }}</div>
                                    <div class="text-sm text-gray-400">{{ __('Bodovi za poraz') }}</div>
                                </div>
                            </div>
                        </div>
                        @endif

                        @if($league->sport->slug === 'stoni-tenis')
                        <div class="mt-6 pt-6 border-t border-gray-600/50">
                            <h4 class="text-lg font-semibold text-white mb-4">{{ __('Pravila meča') }}</h4>
                            <div class="text-center">
                                <div class="text-lg font-semibold text-white">{{ __('Najbolje od :sets setova (:wins setova za pobjedu)', ['sets' => ($league->settings['sets_to_win'] ?? 2) * 2 - 1, 'wins' => $league->settings['sets_to_win'] ?? 2]) }}</div>
                                <div class="text-sm text-gray-400">{{ __('Setovi za pobjedu u meču') }}</div>
                            </div>
                        </div>
                        @endif
                    </div>
                    @endif

                    @if($league->status === 'active')
                    <div class="bg-gray-800/50 backdrop-blur-xl rounded-2xl p-6 border border-gray-700/50 shadow-xl">
                        <h3 class="text-xl font-semibold text-white mb-4">{{ __('Raspored mečeva') }}</h3>

                        @if($league->matches->count() > 0)
                        <div class="space-y-6">
                            @php
                                $matchesByRound = $league->matches->groupBy('round');
                            @endphp

                            @foreach($matchesByRound as $round => $roundMatches)
                            <div>
                                <h4 class="text-lg font-medium text-white mb-3">{{ __('Round :round', ['round' => $round]) }}</h4>
                                <div class="space-y-3">
                                    @foreach($roundMatches as $match)
                                     <a href="{{ route('leagues.matches.show', [$league, $match]) }}"
                                        class="flex flex-col sm:flex-row sm:items-center justify-between p-4 bg-gray-700/30 rounded-lg hover:bg-gray-700/50 transition-colors cursor-pointer block">
                                         <div class="flex items-center space-x-4">
                                             <div class="text-center">
                                                 <div class="text-white font-medium">
                                                     @if($league->is_team_based)
                                                         {{ $match->homeTeam->name ?? 'TBD' }}
                                                     @else
                                                         {{ $match->homePlayer->name ?? 'TBD' }}
                                                     @endif
                                                 </div>
                                             </div>
                                             <div class="text-gray-400">vs</div>
                                             <div class="text-center">
                                                 <div class="text-white font-medium">
                                                     @if($league->is_team_based)
                                                         {{ $match->awayTeam->name ?? 'TBD' }}
                                                     @else
                                                         {{ $match->awayPlayer->name ?? 'TBD' }}
                                                     @endif
                                                 </div>
                                             </div>
                                         </div>
                                         <div class="flex items-center space-x-4 mt-2 sm:mt-0">
                                             @if($match->status === 'completed')
                                                 <div class="text-green-400 font-bold text-lg">
                                                     {{ $match->home_score }} - {{ $match->away_score }}
                                                 </div>
                                             @elseif($match->status === 'forfeited')
                                                 <div class="text-orange-400 italic">
                                                     Cancelled
                                                 </div>
                                             @elseif($match->status === 'cancelled')
                                                 <div class="text-orange-400 italic">
                                                     Cancelled
                                                 </div>
                                             @elseif($match->scheduled_at)
                                                 <div class="text-gray-400">
                                                     {{ $match->scheduled_at->format('M d, H:i') }}
                                                 </div>
                                             @endif
                                             <span class="px-2 py-1 text-xs rounded-full
                                                 @if($match->status === 'completed') bg-green-500/20 text-green-400
                                                 @elseif($match->status === 'in_progress') bg-yellow-500/20 text-yellow-400
                                                 @elseif($match->status === 'forfeited') bg-red-500/20 text-red-400
                                                 @elseif($match->status === 'cancelled') bg-orange-500/20 text-orange-400
                                                 @else bg-gray-500/20 text-gray-400 @endif">
                                                 {{ ucfirst(str_replace('_', ' ', $match->status)) }}
                                             </span>
                                         </div>
                                    </a>
                                    @endforeach
                                </div>
                            </div>
                            @endforeach
                        </div>
                        @else
                        <div class="text-center py-8">
                            <div class="w-16 h-16 bg-gray-700/50 rounded-full flex items-center justify-center mx-auto mb-4">
                                <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3a2 2 0 012-2h4a2 2 0 012 2v4m-6 4v10a2 2 0 002 2h4a2 2 0 002-2V11M9 11h6"></path>
                                </svg>
                            </div>
                            <h4 class="text-white font-semibold mb-2">{{ __('Nema zakazanih mečeva') }}</h4>
                            <p class="text-gray-400">{{ __('Mečevi će biti zakazani kada liga počne.') }}</p>
                        </div>
                        @endif
                    </div>
                    @endif

                    @if($league->status === 'draft')
                    <div class="bg-gray-800/50 backdrop-blur-xl rounded-2xl p-6 border border-gray-700/50 shadow-xl">
                        <h3 class="text-xl font-semibold text-white mb-6">{{ __('Konfiguracija Lige') }}</h3>
                        
                        <form action="{{ route('leagues.update', $league) }}" method="POST" class="space-y-8">
                            @csrf
                            @method('PUT')

                            <div>
                                <label class="block text-lg font-medium text-white mb-4">{{ __('Format takmičenja') }}</label>
                                <div class="space-y-3">
                                    <div class="flex items-center p-3 bg-gray-700/30 rounded-lg hover:bg-gray-700/50 transition-colors">
                                        <input type="radio" id="format_round_robin" name="format" value="round_robin" 
                                               {{ old('format', $league->settings['format'] ?? '') === 'round_robin' ? 'checked' : '' }}
                                               class="w-4 h-4 text-purple-600 bg-gray-700 border-gray-600 focus:ring-purple-500 focus:ring-2">
                                        <label for="format_round_robin" class="ml-3 text-white cursor-pointer flex-1">
                                            <div class="font-medium">{{ __('Jednostruki Round Robin') }}</div>
                                            <div class="text-sm text-gray-400">{{ __('Svaki igrač/tim igra protiv svakog drugog jednom') }}</div>
                                        </label>
                                    </div>
                                    
                                    <div class="flex items-center p-3 bg-gray-700/30 rounded-lg hover:bg-gray-700/50 transition-colors">
                                        <input type="radio" id="format_dual_robin" name="format" value="dual_robin"
                                               {{ old('format', $league->settings['format'] ?? '') === 'dual_robin' ? 'checked' : '' }}
                                               class="w-4 h-4 text-purple-600 bg-gray-700 border-gray-600 focus:ring-purple-500 focus:ring-2">
                                        <label for="format_dual_robin" class="ml-3 text-white cursor-pointer flex-1">
                                            <div class="font-medium">{{ __('Duple Round Robin') }}</div>
                                            <div class="text-sm text-gray-400">{{ __('Svaki igrač/tim igra protiv svakog drugog dva puta') }}</div>
                                        </label>
                                    </div>
                                    
                                    <div class="flex items-center p-3 bg-gray-700/30 rounded-lg hover:bg-gray-700/50 transition-colors">
                                        <input type="radio" id="format_knockout" name="format" value="knockout"
                                               {{ old('format', $league->settings['format'] ?? '') === 'knockout' ? 'checked' : '' }}
                                               class="w-4 h-4 text-purple-600 bg-gray-700 border-gray-600 focus:ring-purple-500 focus:ring-2">
                                        <label for="format_knockout" class="ml-3 text-white cursor-pointer flex-1">
                                            <div class="font-medium">{{ __('Eliminacioni turnir') }}</div>
                                            <div class="text-sm text-gray-400">{{ __('Jednokratni eliminacioni turnir') }}</div>
                                        </label>
                                    </div>
                                </div>
                            </div>

                            @if(!$league->is_team_based || $league->sport->slug === 'stoni-tenis')
                            <div>
                                <label class="block text-lg font-medium text-white mb-4">{{ __('Sets to Win Match') }}</label>
                                <div class="space-y-3">
                                    <div class="flex items-center p-3 bg-gray-700/30 rounded-lg hover:bg-gray-700/50 transition-colors">
                                        <input type="radio" id="sets_2" name="sets_to_win" value="2"
                                               {{ old('sets_to_win', $league->settings['sets_to_win'] ?? '') == 2 ? 'checked' : '' }}
                                               class="w-4 h-4 text-blue-600 bg-gray-700 border-gray-600 focus:ring-blue-500 focus:ring-2">
                                        <label for="sets_2" class="ml-3 text-white cursor-pointer flex-1">
                                            <div class="font-medium">{{ __('Best of 3 (2 sets to win)') }}</div>
                                            <div class="text-sm text-gray-400">{{ __('Brzi mečevi') }}</div>
                                        </label>
                                    </div>
                                    
                                    <div class="flex items-center p-3 bg-gray-700/30 rounded-lg hover:bg-gray-700/50 transition-colors">
                                        <input type="radio" id="sets_3" name="sets_to_win" value="3"
                                               {{ old('sets_to_win', $league->settings['sets_to_win'] ?? '') == 3 ? 'checked' : '' }}
                                               class="w-4 h-4 text-blue-600 bg-gray-700 border-gray-600 focus:ring-blue-500 focus:ring-2">
                                        <label for="sets_3" class="ml-3 text-white cursor-pointer flex-1">
                                            <div class="font-medium">{{ __('Best of 5 (3 sets to win)') }}</div>
                                            <div class="text-sm text-gray-400">{{ __('Standardni mečevi') }}</div>
                                        </label>
                                    </div>
                                    
                                    <div class="flex items-center p-3 bg-gray-700/30 rounded-lg hover:bg-gray-700/50 transition-colors">
                                        <input type="radio" id="sets_4" name="sets_to_win" value="4"
                                               {{ old('sets_to_win', $league->settings['sets_to_win'] ?? '') == 4 ? 'checked' : '' }}
                                               class="w-4 h-4 text-blue-600 bg-gray-700 border-gray-600 focus:ring-blue-500 focus:ring-2">
                                        <label for="sets_4" class="ml-3 text-white cursor-pointer flex-1">
                                            <div class="font-medium">{{ __('Best of 7 (4 sets to win)') }}</div>
                                            <div class="text-sm text-gray-400">{{ __('Dugi mečevi') }}</div>
                                        </label>
                                    </div>
                                </div>
                            </div>
                            @endif

                            <div>
                                <label class="block text-lg font-medium text-white mb-4">{{ __('Sistem bodovanja') }}</label>
                                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                                    <div>
                                        <label class="block text-sm font-medium text-gray-400 mb-3">{{ __('Bodovi za pobjedu') }}</label>
                                        <div class="space-y-2">
                                            @for($i = 1; $i <= 5; $i++)
                                            <div class="flex items-center">
                                                <input type="radio" id="points_win_{{ $i }}" name="points_win" value="{{ $i }}"
                                                       {{ old('points_win', $league->settings['points_win'] ?? 3) == $i ? 'checked' : '' }}
                                                       class="w-4 h-4 text-green-600 bg-gray-700 border-gray-600 focus:ring-green-500 focus:ring-2">
                                                <label for="points_win_{{ $i }}" class="ml-2 text-white cursor-pointer">{{ $i }} {{ __('points') }}</label>
                                            </div>
                                            @endfor
                                        </div>
                                    </div>
                                    
                                    <div>
                                        <label class="block text-sm font-medium text-gray-400 mb-3">{{ __('Bodovi za neriješeno') }}</label>
                                        <div class="space-y-2">
                                            @for($i = 0; $i <= 3; $i++)
                                            <div class="flex items-center">
                                                <input type="radio" id="points_draw_{{ $i }}" name="points_draw" value="{{ $i }}"
                                                       {{ old('points_draw', $league->settings['points_draw'] ?? 1) == $i ? 'checked' : '' }}
                                                       class="w-4 h-4 text-yellow-600 bg-gray-700 border-gray-600 focus:ring-yellow-500 focus:ring-2">
                                                <label for="points_draw_{{ $i }}" class="ml-2 text-white cursor-pointer">{{ $i }} {{ __('points') }}</label>
                                            </div>
                                            @endfor
                                        </div>
                                    </div>
                                    
                                    <div>
                                        <label class="block text-sm font-medium text-gray-400 mb-3">{{ __('Bodovi za gubitak') }}</label>
                                        <div class="space-y-2">
                                            @for($i = 0; $i <= 2; $i++)
                                            <div class="flex items-center">
                                                <input type="radio" id="points_loss_{{ $i }}" name="points_loss" value="{{ $i }}"
                                                       {{ old('points_loss', $league->settings['points_loss'] ?? 0) == $i ? 'checked' : '' }}
                                                       class="w-4 h-4 text-red-600 bg-gray-700 border-gray-600 focus:ring-red-500 focus:ring-2">
                                                <label for="points_loss_{{ $i }}" class="ml-2 text-white cursor-pointer">{{ $i }} {{ __('points') }}</label>
                                            </div>
                                            @endfor
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="pt-6 border-t border-gray-600/50">
                                <button type="submit"
                                        class="w-full bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white px-8 py-4 rounded-lg font-medium transition-all duration-200 transform hover:scale-105 shadow-lg hover:shadow-purple-500/25">
                                    {{ __('Spremi postavke lige') }}
                                </button>
                            </div>
                        </form>
                    </div>
                    @else
                    <div class="bg-gray-800/50 backdrop-blur-xl rounded-2xl p-6 border border-gray-700/50 shadow-xl">
                        <h3 class="text-xl font-semibold text-white mb-4">{{ __('Postavke lige') }}</h3>
                        <div class="space-y-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-400 mb-1">{{ __('Format natjecanja') }}</label>
                                <p class="text-white">
                                    @php
                                        $format = $league->settings['format'] ?? 'round_robin';
                                    @endphp
                                    @switch($format)
                                        @case('round_robin')
                                            {{ __('Single Round Robin') }}
                                            @break
                                        @case('dual_robin')
                                            {{ __('Double Round Robin') }}
                                            @break
                                        @case('knockout')
                                            {{ __('Knockout Only') }}
                                            @break
                                        @default
                                            {{ ucfirst(str_replace('_', ' ', $format)) }}
                                    @endswitch
                                </p>
                            </div>

                            @if(true)
                                <div class="grid grid-cols-3 gap-4">
                                    <div>
                                        <label class="block text-sm font-medium text-gray-400 mb-1">{{ __('Bodovi za pobjedu') }}</label>
                                        <p class="text-white">{{ $league->settings['points_win'] ?? 3 }}</p>
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium text-gray-400 mb-1">{{ __('Bodovi za neriješeno') }}</label>
                                        <p class="text-white">{{ $league->settings['points_draw'] ?? 1 }}</p>
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium text-gray-400 mb-1">{{ __('Bodovi za gubitak') }}</label>
                                        <p class="text-white">{{ $league->settings['points_loss'] ?? 0 }}</p>
                                    </div>
                                </div>
                            @endif

                            @if($league->sport->slug === 'stoni-tenis')
                                <div>
                                    <label class="block text-sm font-medium text-gray-400 mb-1">{{ __('Setovi za pobjedu u meču') }}</label>
                                    <p class="text-white">{{ __('Najbolje od :sets setova (:wins setova za pobjedu)', ['sets' => ($league->settings['sets_to_win'] ?? 2) * 2 - 1, 'wins' => $league->settings['sets_to_win'] ?? 2]) }}</p>
                                </div>
                            @endif
                        </div>
                    </div>
                    @endif

                    <div class="bg-gray-800/50 backdrop-blur-xl rounded-2xl p-6 border border-gray-700/50 shadow-xl">
                        <div class="flex items-center justify-between mb-4">
                            <h3 class="text-xl font-semibold text-white">
                                {{ $league->is_team_based ? __('Teams') : __('Players') }}
                            </h3>
                        </div>

                        @if($league->is_team_based)
                            @if($league->teams->count() > 0)
                            <div class="space-y-3">
                                @foreach($league->teams as $team)
                                <div class="flex items-center justify-between p-4 bg-gray-700/30 rounded-lg">
                                    <div>
                                        <h4 class="text-white font-medium">{{ $team->name }}</h4>
                                        <p class="text-gray-400 text-sm">{{ $team->players->count() }} igrača</p>
                                    </div>
                                    <div class="flex items-center space-x-2">
                                        <span class="px-2 py-1 text-xs rounded-full bg-blue-500/20 text-blue-400">
                                            Aktivno
                                        </span>
                                    </div>
                                </div>
                                @endforeach
                            </div>
                            @else
                            <div class="text-center py-8">
                                <div class="w-16 h-16 bg-gray-700/50 rounded-full flex items-center justify-center mx-auto mb-4">
                                    <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path>
                                    </svg>
                                </div>
                                <h4 class="text-white font-semibold mb-2">{{ __('Nema timova još') }}</h4>
                                <p class="text-gray-400">{{ __('Započnite dodavanjem svog prvog tima.') }}</p>
                            </div>
                            @endif
                        @else
                            @if($league->players->count() > 0)
                            <div class="space-y-3">
                                @foreach($league->players as $player)
                                <div class="flex items-center justify-between p-4 bg-gray-700/30 rounded-lg">
                                    <div>
                                        <h4 class="text-white font-medium">{{ $player->name }}</h4>
                                        @if($player->email)
                                        <div class="text-gray-400 text-sm">{{ $player->email }}</div>
                                        @endif
                                    </div>
                                    <div class="flex items-center space-x-2">
                                        <span class="px-2 py-1 text-xs rounded-full bg-green-500/20 text-green-400">
                                            Active
                                        </span>
                                        <span class="text-gray-400 text-xs">
                                            Joined {{ \Carbon\Carbon::parse($player->pivot->joined_at)->format('M d, Y') }}
                                        </span>
                                    </div>
                                </div>
                                @endforeach
                            </div>
                            @else
                            <div class="text-center py-8">
                                <div class="w-16 h-16 bg-gray-700/50 rounded-full flex items-center justify-center mx-auto mb-4">
                                    <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
                                    </svg>
                                </div>
                                <h4 class="text-white font-semibold mb-2">{{ __('Nema igrača u ligi') }}</h4>
                                <p class="text-gray-400">{{ __('Počnite dodavanjem igrača u ligu.') }}</p>
                            </div>
                            @endif
                        @endif
                    </div>

                    @if($league->status === 'draft')
                    <div class="bg-gray-800/50 backdrop-blur-xl rounded-2xl p-6 border border-gray-700/50 shadow-xl">
                        <h3 class="text-xl font-semibold text-white mb-4">{{ __('Izaberite igrače za početak lige') }}</h3>

                        @php
                            // Get players that are not already in the league
                            $currentPlayerIds = $league->players->pluck('id')->toArray();
                            $availablePlayers = $organization->players
                                ->filter(function($player) use ($currentPlayerIds) {
                                    return !in_array($player->id, $currentPlayerIds);
                                });
                        @endphp

                        @if($availablePlayers->count() > 0)
                        <form id="addPlayersForm" action="{{ route('leagues.addPlayers', $league) }}" method="POST">
                            @csrf
                            @method('POST')

                            <div class="space-y-3 mb-6">
                                @foreach($availablePlayers as $player)
                                <div class="flex items-center p-4 bg-gray-700/30 rounded-lg">
                                    <input type="checkbox" id="player_{{ $player->id }}" name="player_ids[]" value="{{ $player->id }}"
                                           class="w-4 h-4 text-green-600 bg-gray-700 border-gray-600 rounded focus:ring-green-500 focus:ring-2">
                                    <label for="player_{{ $player->id }}" class="ml-3 flex-1">
                                        <div class="text-white font-medium">{{ $player->name }}</div>
                                        @if($player->email)
                                        <div class="text-gray-400 text-sm">{{ $player->email }}</div>
                                        @endif
                                    </label>
                                </div>
                                @endforeach
                            </div>

                            <div class="flex items-center justify-between">
                                <div class="text-sm text-gray-400">
                                    {{ __('Izabrano:') }} <span id="selectedCount">0</span> {{ __('igrača') }}
                                </div>
                                <button type="submit"
                                        class="bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white px-6 py-3 rounded-lg font-medium transition-all duration-200 transform hover:scale-105 shadow-lg hover:shadow-green-500/25">
                                    {{ __('Dodaj izabrane igrače u ligu') }}
                                </button>
                            </div>
                        </form>
                        @elseif($organization->players->count() > 0)
                        <div class="text-center py-8">
                            <div class="w-16 h-16 bg-gray-700/50 rounded-full flex items-center justify-center mx-auto mb-4">
                                <svg class="w-8 h-8 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                                </svg>
                            </div>
                            <h4 class="text-white font-semibold mb-2">{{ __('Svi igrači su već dodati') }}</h4>
                            <p class="text-gray-400">{{ __('Svi igrači iz ove organizacije su dodati u ligu.') }}</p>
                        </div>
                        @else
                        <div class="text-center py-8">
                            <div class="w-16 h-16 bg-gray-700/50 rounded-full flex items-center justify-center mx-auto mb-4">
                                <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v3m0 0v3m0-3h3m-3 0H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                                </svg>
                            </div>
                            <h4 class="text-white font-semibold mb-2">{{ __('Nema dostupnih igrača') }}</h4>
                            <p class="text-gray-400">{{ __('Prvo dodajte igrače u vašu organizaciju.') }}</p>
                        </div>
                        @endif
                    </div>
                    @endif

                    @if($league->status === 'draft')
                    <div class="bg-gray-800/50 backdrop-blur-xl rounded-2xl p-6 border border-gray-700/50 shadow-xl">
                        <h3 class="text-xl font-semibold text-white mb-4">{{ __('Dodaj igrača po email-u') }}</h3>
                        <p class="text-gray-400 text-sm mb-6">{{ __('Pretraži registrovane korisnike po email-u i dodaj ih kao igrače u ovu ligu.') }}</p>

                        @livewire('add-player-by-email', ['organization' => $organization, 'league' => $league])
                    </div>
                    @endif
                </div>

                <div class="space-y-6">

                    <div class="bg-gray-800/50 backdrop-blur-xl rounded-2xl p-6 border border-gray-700/50 shadow-xl">
                        <h3 class="text-lg font-semibold text-white mb-4">{{ __('Brze radnje') }}</h3>
                        <div class="space-y-3">
                            @if($league->is_team_based && $league->status === 'draft')
                            <a href="{{ route('leagues.team-management', $league) }}"
                               class="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white px-4 py-3 rounded-lg font-medium transition-all duration-200 transform hover:scale-105 shadow-lg hover:shadow-blue-500/25 text-center block mb-3">
                                Upravljaj timovima i igračima
                            </a>
                            @endif

                            @if($league->status === 'draft' && (($league->is_team_based && $league->teams->count() >= 2) || (!$league->is_team_based && $league->players->count() >= 2)))
                            <form method="POST" action="{{ route('leagues.start', $league) }}"
                                  onsubmit="return confirm('{{ __('Are you sure you want to start this league? This will generate matches and standings.') }}')"
                                  class="w-full">
                                @csrf
                                @method('PATCH')
                                <button type="submit"
                                        class="w-full bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white px-4 py-3 rounded-lg font-medium transition-all duration-200 transform hover:scale-105 shadow-lg hover:shadow-green-500/25 mb-3">
                                    {{ __('Start League') }}
                                </button>
                            </form>
                            @endif

                            @if($league->status !== 'draft' && $organization->user_id === auth()->id())
                            <form method="POST" action="{{ route('leagues.reset', $league) }}"
                                  onsubmit="return confirm('{{ __('Are you sure you want to reset this league? All matches and standings will be deleted and the league will return to draft status.') }}')"
                                  class="w-full">
                                @csrf
                                <button type="submit"
                                        class="w-full bg-gradient-to-r from-orange-600 to-orange-700 hover:from-orange-700 hover:to-orange-800 text-white px-4 py-3 rounded-lg font-medium transition-all duration-200 transform hover:scale-105 shadow-lg hover:shadow-orange-500/25 mb-3">
                                    {{ __('Restartuj ligu') }}
                                </button>
                            </form>
                            @endif

                            <a href="{{ route('organizations.show', $organization) }}"
                               class="w-full bg-gray-700/50 hover:bg-gray-600/50 text-white px-4 py-3 rounded-lg font-medium transition-all duration-200 text-center block">
                                Vrati se na organizaciju
                            </a>

                            <hr class="border-gray-600/50 my-4">

                            <!-- Public Visibility Toggle -->
                            @if($organization->user_id === auth()->id())
                            <div class="bg-gray-700/30 rounded-lg p-4 border border-gray-600/30">
                                <form method="POST" action="{{ route('leagues.update', $league) }}" class="space-y-3">
                                    @csrf
                                    @method('PUT')
                                    
                                    <input type="hidden" name="is_public" value="0">
                                    
                                    <div class="flex items-center justify-between">
                                        <div>
                                            <h4 class="text-white font-medium">Javna Vidljivost</h4>
                                            <p class="text-sm text-gray-400">Učini ovu ligu vidljivom na javnoj web stranici</p>
                                        </div>
                                        <label class="relative inline-flex items-center cursor-pointer">
                                            <input type="checkbox"
                                                   name="is_public"
                                                   value="1"
                                                   {{ $league->isPublic() ? 'checked' : '' }}
                                                   class="sr-only peer"
                                                   onchange="this.form.submit()">
                                            <div class="w-11 h-6 bg-gray-600 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300/20 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                                        </label>
                                    </div>
                                </form>
                            </div>

                            <hr class="border-gray-600/50 my-4">
                            @endif

                            @if($organization->user_id === auth()->id())
                            <form method="POST" action="{{ route('leagues.destroy', $league) }}"
                                  onsubmit="return confirm('{{ __('Are you sure you want to delete this league? This action cannot be undone.') }}')"
                                  class="w-full">
                                @csrf
                                @method('DELETE')
                                <button type="submit"
                                        class="w-full bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white px-4 py-3 rounded-lg font-medium transition-all duration-200 transform hover:scale-105 shadow-lg hover:shadow-red-500/25">
                                    Obriši ligu
                                </button>
                            </form>
                            @endif
                        </div>
                    </div>

                    <div class="bg-gray-800/50 backdrop-blur-xl rounded-2xl p-6 border border-gray-700/50 shadow-xl">
                        <h3 class="text-lg font-semibold text-white mb-4">Statistika</h3>
                        <div class="space-y-4">
                            <div class="flex justify-between">
                                <span class="text-gray-400">{{ $league->is_team_based ? 'Timovi' : 'Igrači' }}</span>
                                <span class="text-white font-medium">{{ $league->is_team_based ? $league->teams->count() : $league->players->count() }}</span>
                            </div>
                            @if($league->status === 'active')
                            <div class="flex justify-between">
                                <span class="text-gray-400">Ukupno mečeva</span>
                                <span class="text-white font-medium">{{ $league->matches->count() }}</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-400">Završeni</span>
                                <span class="text-white font-medium">{{ $league->matches->where('status', 'completed')->count() }}</span>
                            </div>
                            @if($league->standings->count() > 0)
                            <div class="flex justify-between">
                                <span class="text-gray-400">Lider</span>
                                <span class="text-white font-medium">{{ $league->standings->sortBy('position')->first()->participant_name }}</span>
                            </div>
                            @endif
                            @if($league->is_team_based && $league->max_teams)
                            <div class="flex justify-between">
                                <span class="text-gray-400">{{ __('Maksimalno timova') }}</span>
                                <span class="text-white font-medium">{{ $league->max_teams }}</span>
                            </div>
                            @endif
                            @endif
                            <div class="flex justify-between">
                                <span class="text-gray-400">{{ __('Status') }}</span>
                                <span class="text-white font-medium">{{ ucfirst($league->status) }}</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Update selected players count
        function updateSelectedCount() {
            const selectedCountElement = document.getElementById('selectedCount');
            if (selectedCountElement) {
                const checkboxes = document.querySelectorAll('input[name="player_ids[]"]:checked');
                selectedCountElement.textContent = checkboxes.length;
            }
        }

        // Add event listeners to checkboxes
        document.querySelectorAll('input[name="player_ids[]"]').forEach(checkbox => {
            checkbox.addEventListener('change', updateSelectedCount);
        });

        // Initialize count on page load
        updateSelectedCount();
    </script>
</x-app-layout>